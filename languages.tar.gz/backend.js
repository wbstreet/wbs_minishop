//"use strict"

//import {mod_minishop_Request2} from "./frontend.js";