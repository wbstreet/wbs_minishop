<?php

$TEXT['SORTED_BY'] = "Сортировать по";
$TEXT['SORTED_BY_TITLE'] = "Название";
$TEXT['SORTED_BY_PRICE'] = "Цена";