<?php

$TEXT['SORTED_BY'] = "Sort by";
$TEXT['SORTED_BY_TITLE'] = "Title";
$TEXT['SORTED_BY_PRICE'] = "Price";